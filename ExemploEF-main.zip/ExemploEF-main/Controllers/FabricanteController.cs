﻿using Microsoft.AspNetCore.Mvc;
using ExemploEF.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ExemploEF.Controllers
{
    public class FabricanteController : Controller
    {
        public Context context;
        public FabricanteController (Context CTX) 
        { 
            context = CTX;
        }
        public IActionResult Index()
        {
            return View(context.Fabricantes.Include(p => p.Produtos));

        }
        public IActionResult Create()
        {
            //utiliza uma Viewbag para gerar uma lista com os nomes dos fabricantes
            ViewBag.FabricanteID = new SelectList(context.Fabricantes
                .OrderBy(f => f.Nome), "FabricanteID", "Nome");
            return View();
        }

        [HttpPost]
        public IActionResult Create(Fabricante fabricante)
        {
            context.Add(fabricante);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult Details(int id)
        {
            var fabricante = context.Fabricantes
                .Include(f => f.Nome)
                .FirstOrDefault(p => p.FabricanteID == id);
            return View(fabricante);
        }
        public IActionResult Edit(int id)
        {
            var fabricante = context.Fabricantes.Find(id);
            ViewBag.FabricanteID = new SelectList(context.Fabricantes.OrderBy(f => f.Nome), "FabricanteID", "Nome");
            return View(fabricante);
        }
        [HttpPost]
        public IActionResult Edit(Fabricante fabricante)
        {
            //avisa a EF que o registro será modificado
            context.Entry(fabricante).State = EntityState.Modified;
            context.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult Delete(int id)
        {
            var fabricante = context.Fabricantes.Include(f => f.Nome).FirstOrDefault(p => p.FabricanteID == id);
            return View(fabricante);
        }
        [HttpPost]
        public IActionResult Delete(Fabricante fabricante)
        {
            context.Fabricantes.Remove(fabricante);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
